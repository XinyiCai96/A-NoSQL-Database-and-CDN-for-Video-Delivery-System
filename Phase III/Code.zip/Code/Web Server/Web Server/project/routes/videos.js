var express = require('express');
var router = express.Router();
var cassandra = require('cassandra-driver');

// var client = cassandra.Client({contactPoints: ['127.0.0.1']});
// client.connect(function(err,result){
  // console.log('index: cassandra connected');
// });
const client = new cassandra.Client({
  contactPoints: ['127.0.0.1'],
  localDataCenter: 'datacenter1'
});

var getVidByID = 'SELECT * FROM library.videos where video_id = ?'

/* GET users listing. */
router.get('/:video_id', function(req, res, next) {
  client.execute(getVidByID,[req.params.id], function(err,result){
    if(err){
      res.status(404).send({msg: err});
    } else {
      res.render('videos', {
        videos: result.rows
      })
    }
  });
});

module.exports = router;
